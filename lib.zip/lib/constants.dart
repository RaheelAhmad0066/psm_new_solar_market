import 'package:flutter/material.dart';

Color dimGreyColor = const Color.fromRGBO(50, 50, 50, 0.2);

const Color KpurpleColor = Color(0xFF55185D);
const Color kSplashColor = Color(0xFF472D2D);
const Color kPrimaryColor = Color(0xFF00BF63);
const Color kLightGreenColor = Color(0xFF80aa23);
const Color kblack = Colors.black;

const Color KyellowColor = Color(0xFFFFD524);
const Color KgreenColor = Color(0xFF2EB62C);
const Color KredColor = Color(0xFFFF0000);
TextStyle KtextStyle =
    const TextStyle(fontWeight: FontWeight.bold, fontSize: 20);



